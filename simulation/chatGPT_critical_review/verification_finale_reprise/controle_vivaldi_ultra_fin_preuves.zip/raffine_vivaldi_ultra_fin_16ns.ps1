param([ValidateSet(1,2,4,10)][int]$VivaldiUltraFils = 10)
$ErrorActionPreference = 'Stop'
$uRacine = 'C:\Jacques\liteVNA\MicroWaveTomography'
$uPython = 'C:\Users\jfeld\anaconda3\envs\openems\python.exe'
$uBase = Join-Path $uRacine 'simulation\resultats\pcbway_r1'
$uModule = Join-Path $uRacine 'simulation\raffine_qualification_pcbway.py'
$uModuleSha = '533c2678aba6219073601fc0101682bc82ae52c5b221ce66bfecfac323f859fb'
$uEtat = Get-Content -LiteralPath (Join-Path $uBase 'journaux\controle_initial\pipeline_statut_initial.json') -Raw -Encoding UTF8 | ConvertFrom-Json

function Verifier-SourcesVivaldiUltra {
    foreach ($uSource in @($uEtat.sources_physiques_sha256.PSObject.Properties) + @($uEtat.scripts_orchestration_sha256.PSObject.Properties)) {
        $uFichier = Join-Path (Join-Path $uRacine 'simulation') $uSource.Name
        if ((Get-FileHash -LiteralPath $uFichier -Algorithm SHA256).Hash.ToLowerInvariant() -ne $uSource.Value) { throw ('Source modifiee : ' + $uSource.Name) }
    }
    if ((Get-FileHash -LiteralPath $uModule -Algorithm SHA256).Hash.ToLowerInvariant() -ne $uModuleSha) { throw 'Module de raffinement modifie.' }
}

function Lancer-CommandeVivaldiUltra {
    param([string[]]$uArguments,[string]$uNom)
    $uPrefixe = Join-Path $uBase ('journaux\' + $uNom)
    if ((Test-Path -LiteralPath ($uPrefixe + '.log')) -or (Test-Path -LiteralPath ($uPrefixe + '.stderr.log'))) { throw ('Journaux deja presents : ' + $uNom) }
    $uProcessus = Start-Process -FilePath $uPython -ArgumentList $uArguments -WorkingDirectory $uRacine -WindowStyle Hidden -RedirectStandardOutput ($uPrefixe + '.log') -RedirectStandardError ($uPrefixe + '.stderr.log') -PassThru
    $uHandle = $uProcessus.Handle
    Write-Output ('Lancement ' + $uNom + ', PID ' + $uProcessus.Id + ', fils ' + $VivaldiUltraFils + ', UTC ' + [DateTime]::UtcNow.ToString('o'))
    $uProcessus.WaitForExit()
    if ($uProcessus.ExitCode -ne 0) { throw ('Commande en echec : ' + $uNom + ', code ' + $uProcessus.ExitCode) }
    Write-Output ('Termine ' + $uNom + ', UTC ' + [DateTime]::UtcNow.ToString('o'))
}

if ($uEtat.etat -ne 'comparaison_terminee') { throw 'La campagne initiale doit etre terminee.' }
foreach ($uProfil in @('ultra_fin_16ns','ultra_fin_12ns')) {
    $uDossier = Join-Path (Join-Path $uBase 'vivaldi_tomographie') $uProfil
    if (Test-Path -LiteralPath $uDossier) { throw ('Dossier existant, aucun ecrasement : ' + $uDossier) }
}
foreach ($uJournal in @('vivaldi_tomographie_ultra_fin_16ns_raffinement_r1','vivaldi_tomographie_ultra_fin_12ns_prefixe_r1')) {
    foreach ($uSuffixe in @('.log','.stderr.log')) {
        $uChemin = Join-Path $uBase ('journaux\' + $uJournal + $uSuffixe)
        if (Test-Path -LiteralPath $uChemin) { throw ('Journal existant, aucun nouveau calcul : ' + $uChemin) }
    }
}
Verifier-SourcesVivaldiUltra
Lancer-CommandeVivaldiUltra -uNom 'vivaldi_tomographie_ultra_fin_16ns_raffinement_r1' -uArguments @('-B','-X','utf8','-u',$uModule,'--antenne','vivaldi_tomographie','--niveau','ultra_fin','--duree-ns','16','--fils',[string]$VivaldiUltraFils,'--base',$uBase)
Verifier-SourcesVivaldiUltra
Lancer-CommandeVivaldiUltra -uNom 'vivaldi_tomographie_ultra_fin_12ns_prefixe_r1' -uArguments @('-B','-X','utf8','-u',(Join-Path $uRacine 'simulation\fenetre_sondes.py'),'--source',(Join-Path $uBase 'vivaldi_tomographie\ultra_fin_16ns'),'--sortie',(Join-Path $uBase 'vivaldi_tomographie\ultra_fin_12ns'),'--duree-ns','12')
