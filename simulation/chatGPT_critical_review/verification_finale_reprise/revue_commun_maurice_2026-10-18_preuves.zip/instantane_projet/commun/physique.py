"""
PHYSIQUE ET TRAITEMENT -- ce qui vaut quel que soit le banc.

Constantes, permittivites des milieux, indice complexe, profil de distance et
resolution. Aucune geometrie, aucun modele de scene : chaque projet construit
les siens a partir d'ici.
"""

import numpy as np

c = 299_792_458.0
eps0 = 8.8541878128e-12


# ---------------------------------------------------------------- milieux
# (eps_r, sigma en S/m) vers 3 GHz
MILIEUX = {
    "air":          (1.0, 0.0),
    "pmma":         (2.6, 0.0),
    "ptfe":         (2.1, 0.0),
    "verre":        (6.9, 0.05),
    "os":           (11.0, 0.30),
    "os_spongieux": (20.0, 0.80),
    "peau":         (39.0, 1.40),
    "cartilage":    (42.5, 1.60),
    "eau":          (70.0, 0.05),
    "metal":        (None, None),      # r23 = -1
}


def milieu(nom):
    """Rend (eps_r, sigma) a partir d'un nom ou d'une valeur numerique."""
    if isinstance(nom, (int, float)):
        e = float(nom)
        return e, (0.0 if e < 10.0 else 1.6)
    if nom not in MILIEUX:
        raise ValueError(f"milieu inconnu : {nom}. Connus : "
                         + ", ".join(MILIEUX))
    return MILIEUX[nom]


# ======================================================================
# MODELE PHYSIQUE
# ======================================================================
def indice(freqs, eps_r, sigma):
    return np.sqrt(eps_r - 1j * sigma / (2 * np.pi * freqs * eps0))


# ======================================================================
# PROFIL DE DISTANCE
# ======================================================================
def profil_distance(freqs, s11, zoom=16, fenetre="hann"):
    """Enveloppe et distance équivalente air (mm) depuis le plan de référence.

    Après SOL, le zéro est le plan de calibration. La réponse de l'antenne
    n'est pas déconvoluée. Le module de l'IFFT est conservé avec le gain de
    la fenêtre (pas une amplitude d'écho corrigée du gain de l'antenne).

    Le pas temporel vaut 1/(n_fft.df) avec df = BW/(N-1). Utiliser 1/BW
    surestime toutes les distances de N/(N-1) -- 1 % a 101 points.
    """
    freqs = np.asarray(freqs, dtype=float)
    s11 = np.asarray(s11, dtype=complex)
    if (freqs.ndim != 1 or s11.ndim != 1 or len(freqs) != len(s11)
            or len(freqs) < 2 or not np.all(np.isfinite(freqs))
            or not np.all(np.isfinite(s11))):
        raise ValueError("Profil : fréquences et S11 finis, unidimensionnels et de même taille requis.")
    ecarts = np.diff(freqs)
    if np.any(ecarts <= 0) or not np.allclose(ecarts, ecarts[0], rtol=1e-9, atol=1e-3):
        raise ValueError("L'IFFT nécessite une grille de fréquences croissante et uniforme.")
    if not isinstance(zoom, (int, np.integer)) or zoom < 1:
        raise ValueError("Le facteur zoom doit être un entier positif.")
    n = len(s11)
    if fenetre == "hann":
        fen = np.hanning(n)
    elif fenetre == "blackman-harris":
        k = np.arange(n) / (n - 1)
        fen = (0.35875 - 0.48829 * np.cos(2 * np.pi * k)
               + 0.14128 * np.cos(4 * np.pi * k)
               - 0.01168 * np.cos(6 * np.pi * k))
    else:
        fen = np.ones(n)
    n_fft = n * zoom
    prof = np.abs(np.fft.ifft(np.asarray(s11) * fen, n=n_fft)) * zoom
    df = (freqs[-1] - freqs[0]) / (n - 1)
    pas = 1.0 / (n_fft * df) * c / 2.0 * 1e3
    dist = np.arange(n_fft) * pas
    demi = n_fft // 2
    return dist[:demi], prof[:demi], pas


def resolution_mm(freqs, fenetre="hann"):
    """Largeur du lobe principal : k.c/(2B), k = 1,7 pour Hann."""
    k = 1.7 if fenetre == "hann" else 2.3
    return k * c / (2 * (freqs[-1] - freqs[0])) * 1e3


def cote_plaque_mm(distance_mm, f_min_hz):
    """Cote minimale d'une plaque de reference, en mm.

    Une plaque ne se comporte en miroir que si elle couvre la premiere zone
    de Fresnel, de rayon sqrt(lambda.d/2) en reflexion monostatique, d'ou la
    cote sqrt(2.lambda.d). Elle grandit avec la distance ET avec la longueur
    d'onde : c'est le BAS de la bande qui dimensionne la plaque.

    Trop petite, la plaque tronque le bas de la bande, et d'autant plus
    qu'elle est loin : la distance apparente en est biaisee, et l'echo
    decroit plus vite que les 6 dB par doublement de distance d'un miroir.
    """
    lam_mm = c / f_min_hz * 1e3
    return float(np.sqrt(2.0 * lam_mm * distance_mm))
