param([ValidateSet(1,2,4,10)][int]$GrandN34Fils = 10)
$ErrorActionPreference = 'Stop'
$uRacine = 'C:\Jacques\liteVNA\MicroWaveTomography'
$uPython = 'C:\Users\jfeld\anaconda3\envs\openems\python.exe'
$uBase = Join-Path $uRacine 'simulation\resultats\pcbway_r1'
$uModule = Join-Path $uRacine 'simulation\raffine_qualification_plus_pcbway.py'
$uOriginalR = Join-Path $uRacine 'simulation\raffine_qualification_pcbway.py'
$uOriginalRSha = '533c2678aba6219073601fc0101682bc82ae52c5b221ce66bfecfac323f859fb'
$uModuleSha = '15fe2ef41de4c4c3c4da0954dc2396fa652f3b75ba18d0f373824a4aab39d3c3'
$uEtat = Get-Content -LiteralPath (Join-Path $uBase 'journaux\controle_initial\pipeline_statut_initial.json') -Raw -Encoding UTF8 | ConvertFrom-Json

function Verifier-SourcesN34Plus {
    foreach ($uSource in @($uEtat.sources_physiques_sha256.PSObject.Properties) + @($uEtat.scripts_orchestration_sha256.PSObject.Properties)) {
        $uFichier = Join-Path (Join-Path $uRacine 'simulation') $uSource.Name
        if ((Get-FileHash -LiteralPath $uFichier -Algorithm SHA256).Hash.ToLowerInvariant() -ne $uSource.Value) { throw ('Source modifiee : ' + $uSource.Name) }
    }
    if ((Get-FileHash -LiteralPath $uOriginalR -Algorithm SHA256).Hash.ToLowerInvariant() -ne $uOriginalRSha) { throw 'Module R533c gele modifie.' }
    if ((Get-FileHash -LiteralPath $uModule -Algorithm SHA256).Hash.ToLowerInvariant() -ne $uModuleSha) { throw 'Module de raffinement modifie.' }
}

function Lancer-CommandeN34Plus {
    param([string[]]$uArguments,[string]$uNom)
    $uPrefixe = Join-Path $uBase ('journaux\' + $uNom)
    if ((Test-Path -LiteralPath ($uPrefixe + '.log')) -or (Test-Path -LiteralPath ($uPrefixe + '.stderr.log'))) { throw ('Journaux deja presents : ' + $uNom) }
    $uProcessus = Start-Process -FilePath $uPython -ArgumentList $uArguments -WorkingDirectory $uRacine -WindowStyle Hidden -RedirectStandardOutput ($uPrefixe + '.log') -RedirectStandardError ($uPrefixe + '.stderr.log') -PassThru
    $uHandle = $uProcessus.Handle
    Write-Output ('Lancement ' + $uNom + ', PID ' + $uProcessus.Id + ', fils ' + $GrandN34Fils + ', UTC ' + [DateTime]::UtcNow.ToString('o'))
    $uProcessus.WaitForExit()
    if ($uProcessus.ExitCode -ne 0) { throw ('Commande en echec : ' + $uNom + ', code ' + $uProcessus.ExitCode) }
    Write-Output ('Termine ' + $uNom + ', UTC ' + [DateTime]::UtcNow.ToString('o'))
}

if ($uEtat.etat -ne 'comparaison_terminee') { throw 'La campagne initiale doit etre terminee.' }
foreach ($uProfil in @('n34_12ns','n34_8ns')) {
    $uDossier = Join-Path (Join-Path $uBase 'diamant_uwb_x18') $uProfil
    if (Test-Path -LiteralPath $uDossier) { throw ('Dossier existant, aucun ecrasement : ' + $uDossier) }
}
$uArchiveControle = Join-Path $uBase 'journaux\controle_raffinement_plus\diamant_uwb_x18\n34_12ns'
if (Test-Path -LiteralPath $uArchiveControle) { throw 'Archive PLUS deja presente, aucun lancement.' }
foreach ($uJournal in @('diamant_uwb_x18_n34_12ns_raffinement_plus_r1','diamant_uwb_x18_n34_8ns_prefixe_r1','diamant_uwb_x18_n34_8ns_validation_plus_r1')) {
    foreach ($uSuffixe in @('.log','.stderr.log')) {
        $uChemin = Join-Path $uBase ('journaux\' + $uJournal + $uSuffixe)
        if (Test-Path -LiteralPath $uChemin) { throw ('Journal existant, aucun nouveau calcul : ' + $uChemin) }
    }
}
Verifier-SourcesN34Plus
Lancer-CommandeN34Plus -uNom 'diamant_uwb_x18_n34_12ns_raffinement_plus_r1' -uArguments @('-B','-X','utf8','-u',$uModule,'--antenne','diamant_uwb_x18','--niveau','n34','--duree-ns','12','--prefixe-ns','8','--fils',[string]$GrandN34Fils,'--base',$uBase)
Verifier-SourcesN34Plus
Lancer-CommandeN34Plus -uNom 'diamant_uwb_x18_n34_8ns_prefixe_r1' -uArguments @('-B','-X','utf8','-u',(Join-Path $uRacine 'simulation\fenetre_sondes.py'),'--source',(Join-Path $uBase 'diamant_uwb_x18\n34_12ns'),'--sortie',(Join-Path $uBase 'diamant_uwb_x18\n34_8ns'),'--duree-ns','8')

Verifier-SourcesN34Plus
Lancer-CommandeN34Plus -uNom 'diamant_uwb_x18_n34_8ns_validation_plus_r1' -uArguments @('-B','-X','utf8','-u',$uModule,'--antenne','diamant_uwb_x18','--niveau','n34','--duree-ns','8','--verifier-seulement','--base',$uBase)
Verifier-SourcesN34Plus
