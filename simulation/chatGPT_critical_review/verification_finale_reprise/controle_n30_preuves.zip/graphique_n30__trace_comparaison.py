"""Trace onze calculs termines, sans FDTD et sans ecrire dans leurs dossiers.

Reproduction dans un dossier neuf :
  python -B -Xutf8 trace_comparaison.py --sortie ../comparaison_extreme_reproduite
Utiliser l'environnement openems et un seul thread OMP/BLAS.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"
os.environ["MPLBACKEND"] = "Agg"
sys.dont_write_bytecode = True
SIM = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(SIM))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import qualifie_pcbway as Q
import raffine_qualification_pcbway as R

PROFILS = ("base_8ns", "fin_8ns", "fin_12ns", "tres_fin_8ns", "tres_fin_12ns",
           "ultra_fin_8ns", "ultra_fin_12ns", "extreme_fin_8ns", "extreme_fin_12ns",
           "n30_8ns", "n30_12ns")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--base", type=Path, default=Path(__file__).resolve().parents[1])
    p.add_argument("--sortie", type=Path, default=Path(__file__).resolve().parent)
    args = p.parse_args()
    base, sortie = args.base.resolve(), args.sortie.resolve()
    png, chiffres = sortie / "comparaison_convergence.png", sortie / "chiffres_exacts.json"
    if png.exists() or chiffres.exists():
        raise FileExistsError("Choisir un dossier de sortie neuf : " + str(sortie))
    if sortie == base or any(sortie.is_relative_to(base / n) for n in PROFILS):
        raise ValueError("La sortie ne doit pas se trouver dans un profil de calcul.")
    R.enregistre(Q)  # Catalogue local uniquement ; R n'est pas une source physique commune.
    donnees, preuves = {}, {}
    for nom in PROFILS:
        niveau, duree = nom.rsplit("_", 1)
        f, s, m, q = Q.charge_calcul(base / nom, exiger_courant=True)
        Q.valide_campagne(m, q, "diamant_uwb_x18", niveau, float(duree[:-2]))
        donnees[nom] = (f, s, m, q)
        preuves[nom] = dict(manifeste_sha256=sha(base / nom / "simulation_manifest.json"),
            s11_sha256=sha(base / nom / "s11.s1p"), indicateurs=Q.indicateurs(f, s))
    a, b, t = (donnees[n] for n in ("extreme_fin_12ns", "n30_12ns", "n30_8ns"))
    for d in donnees.values():
        assert np.array_equal(d[0], b[0])
        assert d[2]["sources_sha256"] == b[2]["sources_sha256"]
        assert d[2]["environnement"] == b[2]["environnement"]
        assert d[3]["geometrie_sha256"] == b[3]["geometrie_sha256"]
    spatial = Q.ecarts(a[0], a[1], b[0], b[1])
    temporel = Q.ecarts(t[0], t[1], b[0], b[1], temporel=True)
    assert t[2]["maillage"] == b[2]["maillage"]
    assert t[2]["execution"]["dt_s"] == b[2]["execution"]["dt_s"]
    masques = {"spatial": (np.abs(a[1]) >= .1) & (np.abs(b[1]) >= .1),
               "temporel": (np.abs(t[1]) >= .1) & (np.abs(b[1]) >= .1)}
    f = b[0] / 1e9
    couleurs = {"base": "#718096", "fin": "#1971c2", "tres_fin": "#2b8a3e",
                "ultra_fin": "#d97706", "extreme_fin": "#7b2cbf", "n30": "#b4232d"}
    noms = {"base": "Base", "fin": "Fin", "tres_fin": "Très fin",
            "ultra_fin": "Ultra fin", "extreme_fin": "Extrême fin", "n30": "N30"}
    plt.rcParams.update({"font.size": 11, "axes.titlesize": 12,
                         "axes.labelsize": 11, "legend.fontsize": 10})
    fig, axes = plt.subplots(3, 1, figsize=(14, 14), sharex=True,
        gridspec_kw={"height_ratios": [1.6, 1, 1]})
    fig.subplots_adjust(left=.085, right=.98, top=.895, bottom=.10, hspace=.58)
    fig.suptitle("Grand losange ×1,8 — comparaison intermédiaire de onze profils", y=.975, fontsize=17)
    fig.text(.5, .944,
        f"PROVISOIRE · ÉCHEC SPATIAL : RMS {spatial['valeurs']['rms_complexe']:.6f} > 0,02 ; p95 {spatial['valeurs']['percentile95_db']:.6f} dB > 1 dB",
        ha="center", color="#a61b1b", fontsize=13, weight="bold")
    fig.text(.5, .921, "Temps : N30 8 → 12 ns accepté ; aucun seuil modifié", ha="center", fontsize=11)
    for nom in PROFILS:
        niveau, duree = nom.rsplit("_", 1)
        db = 20 * np.log10(np.maximum(np.abs(donnees[nom][1]), 1e-18))
        axes[0].plot(f, db, color=couleurs[niveau],
            ls="--" if duree == "8ns" else "-", alpha=.88 if niveau != "n30" else 1,
            lw=2.3 if nom == "n30_12ns" else 1.3,
            label=f"{noms[niveau]} · {duree[:-2]} ns")
    axes[0].axhline(-10, color="#303030", ls=":", lw=.9)
    axes[0].axhline(-6, color="#777777", ls=":", lw=.8)
    axes[0].set(ylabel="S11 (dB)", title="A · Réponse en réflexion calculée, grille commune de 213 points")
    axes[0].legend(loc="upper center", bbox_to_anchor=(.5, -.09), ncol=4,
                   frameon=True, columnspacing=2.4, handlelength=3)
    db_affiches = []
    for nom, d, couleur in (("spatial", a, "#bd5800"), ("temporel", t, "#1261a0")):
        valeurs = spatial if nom == "spatial" else temporel
        etiquette = ("Spatial · extrême 12 → N30 12 ns" if nom == "spatial"
                     else "Temporel · N30 8 → 12 ns")
        axes[1].plot(f, np.abs(d[1] - b[1]), color=couleur, lw=1.8,
            label=f"{etiquette} ; max {valeurs['valeurs']['maximum_complexe']:.6f}")
        axes[1].axhline(valeurs["seuils_acceptation"]["maximum_complexe"], color=couleur,
            ls="--", lw=1, label=f"Seuil {nom} : {valeurs['seuils_acceptation']['maximum_complexe']:g}")
        delta_db = np.abs(20 * np.log10(np.maximum(np.abs(d[1]), 1e-15) /
                                         np.maximum(np.abs(b[1]), 1e-15)))
        courbe_db = np.where(masques[nom], delta_db, np.nan)
        db_affiches.append(courbe_db)
        axes[2].plot(f, courbe_db, color=couleur, lw=1.8,
            label=f"{etiquette} ; p95 {valeurs['valeurs']['percentile95_db']:.6f} dB")
        axes[2].axhline(valeurs["seuils_acceptation"]["percentile95_db"], color=couleur,
            ls="--", lw=1, label=f"Seuil p95 {nom} : {valeurs['seuils_acceptation']['percentile95_db']:g} dB")
    axes[1].set(ylabel="|ΔS11| (sans unité)", ylim=(0, .055),
                title="B · Maxima complexes acceptés ; RMS spatial refusé, contrôle temporel accepté")
    maximum_db_affiche = max(float(np.max(v[np.isfinite(v)])) for v in db_affiches if np.any(np.isfinite(v)))
    plafond_db = 1.08 * maximum_db_affiche
    axes[2].set(ylabel="Écart de module (dB)", xlabel="Fréquence (GHz)", ylim=(0, plafond_db),
        title=f"C · Deux |S11| ≥ −20 dB : spatial {int(masques['spatial'].sum())} points, temporel {int(masques['temporel'].sum())} points ; lacunes exclues")
    for ax in axes:
        ax.set_xlim(1, 6.3)
        ax.grid(True, alpha=.22)
        ax.tick_params(labelbottom=True)
    axes[1].legend(loc="upper left", ncol=1, framealpha=.95)
    axes[2].legend(loc="upper left", ncol=1, framealpha=.95)
    fig.text(.085, .025,
        "Port idéal au bord du PCB ; SMA coaxial et finition ENIG non modélisés en 3D.\n"
        "Les deux seuils en dB portent sur le percentile 95 ; les pics isolés ne sont pas le critère d'acceptation.",
        fontsize=10, color="#454545", va="bottom")
    sortie.mkdir(parents=True, exist_ok=True)
    fig.savefig(png, dpi=180, facecolor="white")
    plt.close(fig)
    rapport = dict(schema="comparaison_provisoire_n30_v1", date_utc=datetime.now(timezone.utc).isoformat(),
        antenne="diamant_uwb_x18", provisoire=True, convergence_spatiale=spatial,
        convergence_temporelle=temporel, reussi=False,
        points_masque={nom: int(np.count_nonzero(m)) for nom, m in masques.items()},
        profils=preuves, sources_physiques_communes_sha256=b[2]["sources_sha256"],
        outils_tracage_sha256={"qualifie_pcbway.py": sha(SIM / "qualifie_pcbway.py"),
            "raffine_qualification_pcbway.py": sha(SIM / "raffine_qualification_pcbway.py"),
            "trace_comparaison.py": sha(__file__)},
        figure=png.name, figure_sha256=sha(png), numpy_version=np.__version__,
        matplotlib_version=matplotlib.__version__,
        maximum_ecart_db_affiche=maximum_db_affiche, limites_panneau_db=[0, plafond_db], marge_verticale_relative=.08,
        note="R est un outil de catalogue au moment du tracage ; il ne fait pas partie des neuf sources physiques communes. Aucun calcul ni profil ni selection modifies.")
    with chiffres.open("x", encoding="utf-8", newline="\n") as fichier:
        json.dump(rapport, fichier, ensure_ascii=False, indent=2)
        fichier.write("\n")
    print(str(png))
    print(str(chiffres))


if __name__ == "__main__":
    main()
