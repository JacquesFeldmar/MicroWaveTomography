"""Graphique Vivaldi provisoire, cinq profils immuables lus sans FDTD.

Reproduire avec Python openems :
  python -B -Xutf8 trace_comparaison.py --sortie ../comparaison_vivaldi_reproduite
La sortie doit etre neuve ; aucun profil ou choix de qualification n'est ecrit.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"
os.environ["MPLBACKEND"] = "Agg"
sys.dont_write_bytecode = True
SIM = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(SIM))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import qualifie_pcbway as Q
import raffine_qualification_pcbway as R

PROFILS = ("base_8ns", "fin_8ns", "fin_12ns", "tres_fin_12ns", "tres_fin_16ns")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--base", type=Path, default=Path(__file__).resolve().parents[1])
    p.add_argument("--sortie", type=Path, default=Path(__file__).resolve().parent)
    args = p.parse_args()
    base, sortie = args.base.resolve(), args.sortie.resolve()
    png, chiffres = sortie / "comparaison_convergence.png", sortie / "chiffres_exacts.json"
    if png.exists() or chiffres.exists():
        raise FileExistsError("Choisir une nouvelle sortie : " + str(sortie))
    if sortie == base or any(sortie.is_relative_to(base / n) for n in PROFILS):
        raise ValueError("La sortie ne doit pas etre un profil de calcul.")
    R.enregistre(Q)
    donnees, preuves = {}, {}
    for nom in PROFILS:
        niveau, duree = nom.rsplit("_", 1)
        f, s, m, q = Q.charge_calcul(base / nom, exiger_courant=True)
        Q.valide_campagne(m, q, "vivaldi_tomographie", niveau, float(duree[:-2]))
        donnees[nom] = (f, s, m, q)
        preuves[nom] = dict(manifeste_sha256=sha(base / nom / "simulation_manifest.json"),
            s11_sha256=sha(base / nom / "s11.s1p"), indicateurs=Q.indicateurs(f, s))
    a, b, c = (donnees[n] for n in ("fin_12ns", "tres_fin_12ns", "tres_fin_16ns"))
    for d in donnees.values():
        assert np.array_equal(d[0], c[0])
        assert d[2]["sources_sha256"] == c[2]["sources_sha256"]
        assert d[2]["environnement"] == c[2]["environnement"]
        assert d[3]["geometrie_sha256"] == c[3]["geometrie_sha256"]
    spatial = Q.ecarts(a[0], a[1], b[0], b[1])
    temporel = Q.ecarts(b[0], b[1], c[0], c[1], temporel=True)
    assert b[2]["maillage"] == c[2]["maillage"]
    assert b[2]["execution"]["dt_s"] == c[2]["execution"]["dt_s"]
    masques = {"spatial": (np.abs(a[1]) >= .1) & (np.abs(b[1]) >= .1),
               "temporel": (np.abs(b[1]) >= .1) & (np.abs(c[1]) >= .1)}
    f = c[0] / 1e9
    courbes = {
        "base_8ns": ("Base · 8 ns", "#718096", "--", 1.3),
        "fin_8ns": ("Fin · 8 ns", "#1971c2", "--", 1.3),
        "fin_12ns": ("Fin · 12 ns", "#1971c2", "-", 1.5),
        "tres_fin_12ns": ("Très fin · 12 ns", "#2b8a3e", "-", 1.5),
        "tres_fin_16ns": ("Très fin · 16 ns", "#7b2cbf", "-", 2.3),
    }
    plt.rcParams.update({"font.size": 11, "axes.titlesize": 12,
                         "axes.labelsize": 11, "legend.fontsize": 10})
    fig, axes = plt.subplots(3, 1, figsize=(14, 14), sharex=True,
        gridspec_kw={"height_ratios": [1.6, 1, 1]})
    fig.subplots_adjust(left=.085, right=.98, top=.895, bottom=.10, hspace=.55)
    fig.suptitle("Vivaldi — comparaison intermédiaire de cinq profils", y=.975, fontsize=17)
    fig.text(.5, .944, "PROVISOIRE · CONVERGENCE SPATIALE REFUSÉE", ha="center",
        color="#a61b1b", fontsize=14, weight="bold")
    fig.text(.5, .921,
        f"Spatial : max {spatial['valeurs']['maximum_complexe']:.6f} > 0,05 ; RMS {spatial['valeurs']['rms_complexe']:.6f} > 0,02 ; p95 {spatial['valeurs']['percentile95_db']:.6f} dB > 1 dB",
        ha="center", fontsize=11)
    for nom in PROFILS:
        label, couleur, style, epaisseur = courbes[nom]
        axes[0].plot(f, 20*np.log10(np.maximum(np.abs(donnees[nom][1]), 1e-18)),
            color=couleur, ls=style, lw=epaisseur, label=label)
    axes[0].axhline(-10, color="#303030", ls=":", lw=.9)
    axes[0].axhline(-6, color="#777777", ls=":", lw=.8)
    axes[0].set(ylabel="S11 (dB)", title="A · Réponse en réflexion calculée, grille commune de 213 points")
    axes[0].legend(loc="upper center", bbox_to_anchor=(.5, -.09), ncol=3,
                   frameon=True, columnspacing=2.4, handlelength=3)
    for nom, gauche, droite, couleur in (("spatial", a, b, "#bd5800"),
                                         ("temporel", b, c, "#1261a0")):
        valeurs = spatial if nom == "spatial" else temporel
        label = ("Spatial · fin 12 → très fin 12 ns" if nom == "spatial"
                 else "Temporel · très fin 12 → 16 ns")
        axes[1].plot(f, np.abs(gauche[1]-droite[1]), color=couleur, lw=1.8,
            label=f"{label} ; max {valeurs['valeurs']['maximum_complexe']:.6f}")
        axes[1].axhline(valeurs["seuils_acceptation"]["maximum_complexe"], color=couleur,
            ls="--", lw=1, label=f"Seuil {nom} : {valeurs['seuils_acceptation']['maximum_complexe']:g}")
        db = np.abs(20*np.log10(np.maximum(np.abs(gauche[1]), 1e-15) /
                                  np.maximum(np.abs(droite[1]), 1e-15)))
        axes[2].plot(f, np.where(masques[nom], db, np.nan), color=couleur, lw=1.8,
            label=f"{label} ; p95 {valeurs['valeurs']['percentile95_db']:.6f} dB")
        axes[2].axhline(valeurs["seuils_acceptation"]["percentile95_db"], color=couleur,
            ls="--", lw=1, label=f"Seuil p95 {nom} : {valeurs['seuils_acceptation']['percentile95_db']:g} dB")
    axes[1].set(ylabel="|ΔS11| (sans unité)", ylim=(0, .08),
        title="B · Écart complexe : spatial refusé ; prolongement temporel 12 → 16 ns accepté")
    axes[2].set(ylabel="Écart de module (dB)", xlabel="Fréquence (GHz)", ylim=(0, None),
        title=f"C · Deux |S11| ≥ −20 dB : spatial {int(masques['spatial'].sum())} points, temporel {int(masques['temporel'].sum())} points ; lacunes exclues")
    for ax in axes:
        ax.set_xlim(1, 6.3)
        ax.grid(True, alpha=.22)
        ax.tick_params(labelbottom=True)
    axes[1].legend(loc="upper left", framealpha=.95)
    axes[2].legend(loc="upper left", framealpha=.95)
    fig.text(.085, .025,
        "Port idéal au bord du PCB ; SMA coaxial et finition ENIG non modélisés en 3D.\n"
        "Les seuils en dB portent sur le percentile 95. Passivité numérique respectée ; elle ne prouve pas la convergence spatiale.",
        fontsize=10, color="#454545", va="bottom")
    sortie.mkdir(parents=True, exist_ok=True)
    fig.savefig(png, dpi=180, facecolor="white")
    plt.close(fig)
    rapport = dict(schema="comparaison_provisoire_vivaldi_tres_fin16_v1", date_utc=datetime.now(timezone.utc).isoformat(),
        antenne="vivaldi_tomographie", provisoire=True, convergence_spatiale=spatial,
        convergence_temporelle=temporel,
        reussi=bool(spatial["reussi"] and temporel["reussi"] and preuves["tres_fin_16ns"]["indicateurs"]["passivite_numerique"]),
        points_masque={nom: int(np.count_nonzero(m)) for nom, m in masques.items()},
        profils=preuves, sources_physiques_communes_sha256=c[2]["sources_sha256"],
        outils_tracage_sha256={"qualifie_pcbway.py": sha(SIM / "qualifie_pcbway.py"),
            "raffine_qualification_pcbway.py": sha(SIM / "raffine_qualification_pcbway.py"),
            "trace_comparaison.py": sha(__file__)},
        figure=png.name, figure_sha256=sha(png), numpy_version=np.__version__,
        matplotlib_version=matplotlib.__version__,
        note="R est un outil de catalogue, distinct des sources physiques communes ; aucun profil, source ou selection modifies.")
    with chiffres.open("x", encoding="utf-8", newline="\n") as fichier:
        json.dump(rapport, fichier, ensure_ascii=False, indent=2)
        fichier.write("\n")
    print(str(png))
    print(str(chiffres))


if __name__ == "__main__":
    main()
