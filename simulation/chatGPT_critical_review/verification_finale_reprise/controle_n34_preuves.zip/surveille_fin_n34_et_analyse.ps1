# Observe la file N34 existante. Aucun nouveau FDTD ni changement de sources.
$ErrorActionPreference = 'Stop'
$n34Racine = 'C:\Jacques\liteVNA\MicroWaveTomography'
$n34Sim = Join-Path $n34Racine 'simulation'
$n34Journaux = Join-Path $n34Sim 'resultats\pcbway_r1\journaux'
$n34Python = 'C:\Users\jfeld\anaconda3\envs\openems\python.exe'
$n34Helper = Join-Path $n34Sim 'chatGPT_critical_review\controle_extreme_fin\analyse_extreme_fin.py'
$n34Sortie = Join-Path $n34Sim 'chatGPT_critical_review\controle_extreme_fin\controle_final_n34'
$n34Preuve = Join-Path $n34Journaux 'fin_queue_n34_observee_automatiquement.json'
$n34Console = Join-Path $n34Journaux 'analyse_n34_apres_queue.stdout.log'
$n34Erreurs = Join-Path $n34Journaux 'analyse_n34_apres_queue.stderr.log'
$n34FinAnalyse = Join-Path $n34Journaux 'fin_analyse_n34_automatique.json'
$n34Checkpoint = Join-Path $n34Sim 'chatGPT_critical_review\analyse_grilles_fermees_n30\checkpoint_n34_fige.json'
$n34Queue = Join-Path $n34Journaux 'raffine_grand_losange_n34_plus.ps1'
$n34Utf8 = [System.Text.UTF8Encoding]::new($false)

function Empreinte-N34([string]$n34Chemin) {
    return (Get-FileHash -LiteralPath $n34Chemin -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Ecrire-Neuf-N34([string]$n34Chemin, $n34Objet) {
    $n34Octets = $n34Utf8.GetBytes(($n34Objet | ConvertTo-Json -Depth 20) + "`n")
    $n34Flux = [System.IO.File]::Open($n34Chemin, [System.IO.FileMode]::CreateNew,
        [System.IO.FileAccess]::Write, [System.IO.FileShare]::Read)
    try { $n34Flux.Write($n34Octets, 0, $n34Octets.Length) } finally { $n34Flux.Dispose() }
}
function Verifier-Gel-N34 {
    if ((Empreinte-N34 $n34Checkpoint) -ne '47dacd80fd860c33e5b5bc0dce61332db1b0d31405936359a2ad22ac7add4383') { throw 'Checkpoint N34 different.' }
    $n34Etat = Get-Content -LiteralPath $n34Checkpoint -Raw -Encoding UTF8 | ConvertFrom-Json
    if (@($n34Etat.sources_controle_sha256.PSObject.Properties).Count -ne 17) { throw '17 sources gelees attendues.' }
    foreach ($n34Source in $n34Etat.sources_controle_sha256.PSObject.Properties) {
        if ((Empreinte-N34 (Join-Path $n34Sim $n34Source.Name)) -ne $n34Source.Value) { throw ('Source gelee modifiee : ' + $n34Source.Name) }
    }
    if ((Empreinte-N34 $n34Helper) -ne '2d5215a9e388d2c8cfd6f075eafde1776246d9de3bfe84461a9eda06d94e3b9b') { throw 'Helper N34 different.' }
    if ((Empreinte-N34 $n34Queue) -ne 'a882257a59d5d856fe950e724deab93e5039084ef51542152c5dad86ba035e62') { throw 'File N34 differente.' }
}

foreach ($n34Chemin in @($n34Sortie, $n34Preuve, $n34Console, $n34Erreurs, $n34FinAnalyse)) {
    if (Test-Path -LiteralPath $n34Chemin) { throw ('Sortie deja presente, aucun ecrasement : ' + $n34Chemin) }
}
Verifier-Gel-N34
$n34Processus = Get-Process -Id 22904 -ErrorAction Stop
$n34Identite = Get-CimInstance Win32_Process -Filter 'ProcessId = 22904'
if ($n34Processus.ProcessName -ne 'powershell' -or
    $n34Processus.StartTime.ToUniversalTime().Ticks -ne 639279728411167371 -or
    $n34Identite.CommandLine -notlike '*raffine_grand_losange_n34_plus.ps1*') { throw 'Identite de la file N34 non confirmee.' }
$n34Handle = $n34Processus.Handle  # Garder le handle avant sortie pour lire le vrai code terminal.
$n34DebutObservation = [DateTime]::UtcNow.ToString('o')
Write-Output ('Observation de la file existante PID 22904, UTC ' + $n34DebutObservation)
$n34Processus.WaitForExit()
$n34CodeQueue = $n34Processus.ExitCode
if ($null -eq $n34CodeQueue) { throw 'Code terminal N34 indisponible ; analyse refusee.' }
$n34Attestation = [ordered]@{
    schema = 'fin_queue_n34_code_terminal_v1'; debut_observation_utc = $n34DebutObservation
    fin_observation_utc = [DateTime]::UtcNow.ToString('o'); pid_parent = 22904
    demarrage_parent_utc = '2026-10-19T02:14:01.1167371Z'; code_terminal = $n34CodeQueue
    session_associee = 77627; methode = 'Process.Handle conserve puis WaitForExit et ExitCode'
    queue_sha256 = Empreinte-N34 $n34Queue; observateur_sha256 = Empreinte-N34 $PSCommandPath
    qualification_globale_effectuee = $false
}
Ecrire-Neuf-N34 $n34Preuve $n34Attestation
if ($n34CodeQueue -ne 0) { throw ('File N34 en echec, aucune analyse : code ' + $n34CodeQueue) }
Verifier-Gel-N34
foreach ($n34Chemin in @($n34Sortie, $n34Console, $n34Erreurs, $n34FinAnalyse)) {
    if (Test-Path -LiteralPath $n34Chemin) { throw ('Sortie apparue pendant attente : ' + $n34Chemin) }
}
$env:OMP_NUM_THREADS = '1'
$env:OPENBLAS_NUM_THREADS = '1'
$env:MKL_NUM_THREADS = '1'
$env:NUMEXPR_NUM_THREADS = '1'
$env:MPLBACKEND = 'Agg'
$n34Arguments = @('-B', '-X', 'utf8', '-u', $n34Helper, '--n34',
    '--queue-sortie-zero-confirmee', '--sortie', 'controle_final_n34')
$n34Analyse = Start-Process -FilePath $n34Python -ArgumentList $n34Arguments -WorkingDirectory $n34Racine -WindowStyle Hidden -PassThru -RedirectStandardOutput $n34Console -RedirectStandardError $n34Erreurs
$n34HandleAnalyse = $n34Analyse.Handle
Write-Output ('Analyse seule N34, PID ' + $n34Analyse.Id + ', UTC ' + [DateTime]::UtcNow.ToString('o'))
$n34Analyse.WaitForExit()
$n34CodeAnalyse = $n34Analyse.ExitCode
if ($null -eq $n34CodeAnalyse) { throw 'Code terminal analyse indisponible.' }
Verifier-Gel-N34
$n34Resultat = [ordered]@{
    schema = 'fin_analyse_n34_automatique_v1'; utc = [DateTime]::UtcNow.ToString('o')
    code_terminal_file = $n34CodeQueue; code_terminal_analyse = $n34CodeAnalyse
    attestation_file_sha256 = Empreinte-N34 $n34Preuve
    helper_sha256 = Empreinte-N34 $n34Helper; observateur_sha256 = Empreinte-N34 $PSCommandPath
    stdout_sha256 = Empreinte-N34 $n34Console; stderr_sha256 = Empreinte-N34 $n34Erreurs
    controle_final = $n34Sortie; sources_17_inchangees = $true
    aucun_nouveau_fdtd = $true; qualification_globale_effectuee = $false
    suite = 'Contrelecture independante Q.ecarts, archivage, puis integration seulement si convergence acceptee.'
}
Ecrire-Neuf-N34 $n34FinAnalyse $n34Resultat
Write-Output ('Analyse N34 terminee, code ' + $n34CodeAnalyse + ', UTC ' + $n34Resultat.utc)
exit $n34CodeAnalyse
