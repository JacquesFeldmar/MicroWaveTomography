
import hashlib
import importlib
import json
from pathlib import Path
import sys
import numpy as np
source, sortie = map(Path, sys.argv[1:3])
entrees = json.loads((sortie/'parametres_extraction.json').read_text(encoding='utf-8'))
mere = json.loads((source/'simulation_manifest.json').read_text(encoding='utf-8'))
qualification = json.loads((source/'qualification_entree.json').read_text(encoding='utf-8'))
tag = 'maillage_controle_v2'
if 'moteur' not in mere and 'moteur' not in qualification and 'moteur' not in entrees:
    nom_module = 'fdtd'
    if 'fdtd_maille_controlee.py' in mere['sources_sha256'] or (source/'sources/fdtd_maille_controlee.py').exists():
        raise ValueError('source F2 sans marqueurs F2')
elif mere.get('moteur') == qualification.get('moteur') == entrees.get('moteur') == tag:
    nom_module = 'fdtd_maille_controlee'
    if nom_module+'.py' not in mere['sources_sha256']:
        raise ValueError('source du moteur F2 absente')
else:
    raise ValueError('marqueurs du moteur differents avant extraction')
if entrees['sources_sha256'] != mere['sources_sha256']:
    raise ValueError('inventaire des sources different avant extraction')
for nom, empreinte in entrees['sources_sha256'].items():
    p = (source/'sources'/nom).resolve()
    if not p.is_relative_to((source/'sources').resolve()) or hashlib.sha256(p.read_bytes()).hexdigest() != empreinte:
        raise ValueError('source archivee alteree avant import : '+nom)
sys.path.insert(0, str(source/'sources'))
F = importlib.import_module(nom_module)
if (Path(F.__file__).resolve() != (source/'sources'/(nom_module+'.py')).resolve() or
        F._sources() != entrees['sources_sha256']):
    raise ValueError('moteur importe different des sources archivees')
if nom_module == 'fdtd_maille_controlee' and getattr(F,'NOM_MOTEUR',None) != tag:
    raise ValueError('identite du module F2 incoherente')
from banc import Acquisition, Antenne, Plaque, Maillage, Montage
d = entrees['montage']
montage = Montage(acquisition=Acquisition(**d['acquisition']),
    antenne=Antenne(**d['antenne']), plaque=Plaque(**d['plaque']),
    maillage=Maillage(**d['maillage']))
module = F.charge_antenne(entrees['antenne'])
fdtd, csx, port, _ = F.construit(montage, module,
    x_cm=entrees.get('cible_cm'), dossier=str(sortie),
    x_domaine=entrees.get('x_domaine_cm'),
    distances_communes_cm=entrees.get('distances_communes_cm') or None,
    n_pas=entrees['n_pas'], duree_ns=entrees['duree_ns'],
    dt_impose_s=entrees['dt_s'])
with np.load(source/'maillage.npz',allow_pickle=False) as archive:
    for axe in 'xyz':
        actuel, attendu = np.asarray(csx.GetGrid().GetLines(axe)), archive[axe]
        if (actuel.dtype != attendu.dtype or actuel.ndim != 1 or
                actuel.shape != attendu.shape or actuel.tobytes() != attendu.tobytes()):
            raise ValueError('reconstruction bit exacte du maillage archive differente sur '+axe)
if F._proprietes_matiere(csx)[3] != entrees['materiaux']:
    raise ValueError('reconstruction des materiaux archivee differente')
data = np.loadtxt(source/'s11.s1p', comments=('!', '#'))
frequences, sauve = data[:,0], data[:,1]+1j*data[:,2]
port.CalcPort(str(source), frequences, ref_impedance=montage.acquisition.z_ref)
complet = np.array(port.uf_ref/port.uf_inc, copy=True)
erreur = float(np.max(np.abs(complet-sauve)))
if erreur > 2e-10:
    raise ValueError('CalcPort complet ne reproduit pas S11 mere : '+str(erreur))
port.CalcPort(str(sortie), frequences, ref_impedance=montage.acquisition.z_ref)
derive = port.uf_ref/port.uf_inc
incident = np.abs(port.uf_inc)
if not np.all(np.isfinite(derive)):
    raise ValueError('S11 derive non fini')
np.savez_compressed(sortie/'extraction_calcport.npz',
                    frequences=frequences, s11=derive, s11_parent_relu=complet)
(sortie/'relecture_calcport.json').write_text(json.dumps(dict(
    difference_max_complete_vs_s11_parent=erreur,
    minimum_module_uf_inc=float(incident.min()),
    maximum_module_uf_inc=float(incident.max()),
    minimum_sur_maximum_uf_inc=float(incident.min()/max(incident.max(), 1e-300)),
    extracteur='openEMS.ports.LumpedPort.CalcPort des sources et packages installes',
    phase='DTFT aux temps originaux U et I; demi-pas Yee conserve sans correction ajoutee',
    maillage_archive_identique=True, materiaux_archives_identiques=True), indent=2),
    encoding='utf-8')
